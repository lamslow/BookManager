package com.example.bookmanager.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.BookDAO;
import com.example.bookmanager.hoder.ListBookHoder;
import com.example.bookmanager.model.Book;

import java.util.List;

public class ListBookAdapter extends RecyclerView.Adapter<ListBookHoder> {
    private Context context;
    private List<Book> list;
    private ListBookAdapter listBookAdapter;
    public ListBookAdapter(Context context, List<Book> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ListBookHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.listbook, parent, false);
        ListBookHoder listBookHoder = new ListBookHoder(view);
        return listBookHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListBookHoder holder, final int position) {
        holder.tvNameBook.setText(list.get(position).getTieuDe());
        holder.tvGiaSach.setText(list.get(position).getGiaBan());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View dialogBook = LayoutInflater.from(context).inflate(R.layout.dialog_book, null);
                builder.setView(dialogBook);
                final AlertDialog dialog=builder.show();
                final EditText edtTenSach,edtMaSach,edtNxb,edtTacGia,edtSoLuong,edtGiaban;
                Button btnUpdateBook;
                btnUpdateBook=dialogBook.findViewById(R.id.btnUpdateBook);
                edtGiaban=dialogBook.findViewById(R.id.edtGiaBanDL);
                edtMaSach=dialogBook.findViewById(R.id.edtMaSachDL);
                edtNxb=dialogBook.findViewById(R.id.edtNXBDL);
                edtTacGia=dialogBook.findViewById(R.id.edtMoTaDL);
                edtSoLuong=dialogBook.findViewById(R.id.edtSoLuongDL);
                edtTenSach=dialogBook.findViewById(R.id.edtTenSachDL);

                edtGiaban.setText(list.get(position).getGiaBan());
                edtMaSach.setText(list.get(position).getMaSach());
                edtTacGia.setText(list.get(position).getTacGia());
                edtNxb.setText(list.get(position).getNxb());
                edtSoLuong.setText(list.get(position).getSoLuong());
                edtTenSach.setText(list.get(position).getTieuDe());

                btnUpdateBook.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Book book=new Book();
                        book.setMaSach(edtMaSach.getText().toString());
                        book.setSoLuong(edtSoLuong.getText().toString());
                        book.setGiaBan(edtGiaban.getText().toString());
                        book.setNxb(edtNxb.getText().toString());
                        book.setTacGia(edtTacGia.getText().toString());
                        book.setTieuDe(edtTenSach.getText().toString());

                        BookDAO bookDAO=new BookDAO(context);
                        boolean ressult=bookDAO.UpdateBook(book);
                        if (ressult){
                            Toast.makeText(context, "Cập nhập thành công", Toast.LENGTH_SHORT).show();
                            list=bookDAO.getAllBook();
                            listBookAdapter=new ListBookAdapter(context,list);
                            notifyDataSetChanged();
                            dialog.dismiss();
                        }else {
                            Toast.makeText(context, "Cập nhật không thành công", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });
        holder.imgDelBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String masach =list.get(position).maSach;
                BookDAO bookDAO=new BookDAO(context);
                int result = bookDAO.delBook(masach);
                if (result>0){
                    Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                    list.remove(position);
                    notifyDataSetChanged();
                }else {
                    Toast.makeText(context, "Xóa không thành cồng", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
