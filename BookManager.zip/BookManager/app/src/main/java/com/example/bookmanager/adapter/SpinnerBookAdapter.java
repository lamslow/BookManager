package com.example.bookmanager.adapter;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.example.bookmanager.R;
import com.example.bookmanager.model.Catogory;

import java.util.List;

public class SpinnerBookAdapter implements SpinnerAdapter {
    private Context context;
    private List<Catogory> list;

    public SpinnerBookAdapter(Context context, List<Catogory> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(R.layout.sp_book, parent, false);
        TextView tvSTT, tvTenLoaiSp;
        tvSTT = convertView.findViewById(R.id.tvSTT);
        tvTenLoaiSp = convertView.findViewById(R.id.tvTenLoaiSp);

        tvSTT.setText(position + 1 + " | ");
        tvTenLoaiSp.setText(list.get(position).getTenTheLoai());
        return convertView;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(R.layout.sp_book, parent, false);
        TextView tvSTT, tvTenLoaiSp;
        tvSTT = convertView.findViewById(R.id.tvSTT);
        tvTenLoaiSp = convertView.findViewById(R.id.tvTenLoaiSp);

        tvSTT.setText(position + 1 + "");
        tvTenLoaiSp.setText(list.get(position).getTenTheLoai());
        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
