package com.example.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.bookmanager.model.HoaDonChiTiet;
import com.example.bookmanager.sqlite.BookDatabaseHelper;

import java.util.List;

public class HDCTDao {
    public static final String TABLE_NAME_HDCT = "HoaDonChiTiet";
    private SQLiteDatabase db;
    private BookDatabaseHelper helper;
    public static final String CREATE_TABLE_HDCT = "CREATE TABLE HoaDonChiTiet" +
            "(maHDCT integer primary key autoincrement,maHD text,maSach text,soLuongMua text)";

    public HDCTDao(Context context) {
        helper = new BookDatabaseHelper(context);
        db = helper.getWritableDatabase();
    }

    public long inserHoaDonChiTiet(HoaDonChiTiet hd) {
        ContentValues values = new ContentValues();
        values.put("maHD", hd.getMaHoaDon().getMaHoaDon());
        values.put("maSach", hd.getMaSach().getMaSach());
        values.put("soLuongMua", hd.getSoLuongMua());
        long result=db.insert(TABLE_NAME_HDCT,null,values);
        return result;
    }
    public List<HoaDonChiTiet> getAllHDCT(){
        return null;
    }

}
