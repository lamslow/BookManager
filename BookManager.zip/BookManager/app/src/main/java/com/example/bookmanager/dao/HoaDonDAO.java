package com.example.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.bookmanager.model.Catogory;
import com.example.bookmanager.model.HoaDon;
import com.example.bookmanager.sqlite.BookDatabaseHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class HoaDonDAO {
    public static final String TABLE_NAME_HD="HoaDon";
    private SQLiteDatabase db;
    private BookDatabaseHelper databaseHelper;
    public static final String CREATE_TABLE_HD="CREATE TABLE HoaDon" +
            "(maHoaDon text primary key,ngayMua text)";

    public HoaDonDAO(Context context) {
        databaseHelper=new BookDatabaseHelper(context);
        db=databaseHelper.getWritableDatabase();
    }
    public boolean insertHoaDon(HoaDon hoaDon) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("maHoaDon",hoaDon.getMaHoaDon());
        contentValues.put("ngayMua",hoaDon.getNgayMua());
        long result = db.insert(TABLE_NAME_HD, null, contentValues);
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            Log.e("abc", e.toString());
            return false;
        }
        return true;
    }

    public List<HoaDon> getAllHoaDon() throws ParseException {
        List<HoaDon> dsHoaDon = new ArrayList<>();
        Cursor c = db.query(TABLE_NAME_HD,null,null,null,null,null,null);
        c.moveToFirst();
        while (c.isAfterLast()==false){
            HoaDon hoaDon = new HoaDon();
            hoaDon.setMaHoaDon(c.getString(0));
            hoaDon.setNgayMua(c.getString(1));
            dsHoaDon.add(hoaDon);
            c.moveToNext();
        }
        c.close();
        return dsHoaDon;
    }
    public int deleteHoaDonByID(String mahoadon){
        int result = db.delete(TABLE_NAME_HD,"maHoaDon=?",new String[]{mahoadon});
        if (result == 0)
            return -1;
        return 1;
    }
}
