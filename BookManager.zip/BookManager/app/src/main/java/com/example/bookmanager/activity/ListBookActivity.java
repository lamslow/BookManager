package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.bookmanager.R;
import com.example.bookmanager.adapter.ListBookAdapter;
import com.example.bookmanager.dao.BookDAO;
import com.example.bookmanager.model.Book;

import java.util.ArrayList;
import java.util.List;

public class ListBookActivity extends AppCompatActivity {
    private Toolbar tbListBook;
    private RecyclerView rvListBook;
    private List<Book> listbook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_book);
        rvListBook = findViewById(R.id.rvListBook);
        tbListBook = findViewById(R.id.tbListBook);
        tbListBook.setTitle("Danh sách loại");
        setSupportActionBar(tbListBook);
        BookDAO bookDAO=new BookDAO(this);
        listbook=bookDAO.getAllBook();

        ListBookAdapter listBookAdapter = new ListBookAdapter(this, listbook);
        LinearLayoutManager verticle = new LinearLayoutManager(this);
        rvListBook.setAdapter(listBookAdapter);
        rvListBook.setLayoutManager(verticle);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_book, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itListSach) {
            Intent intent = new Intent(this, AddBookActivity.class);
            startActivity(intent);
        }else if (item.getItemId()==R.id.itTc){
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}
