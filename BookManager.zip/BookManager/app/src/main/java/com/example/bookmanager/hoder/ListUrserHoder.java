package com.example.bookmanager.hoder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;

public class ListUrserHoder extends RecyclerView.ViewHolder {
    public TextView tvNameUrser,tvPhoneUrser;
    public ImageView imgDel;
    public ListUrserHoder(@NonNull View itemView) {
        super(itemView);
        tvNameUrser=itemView.findViewById(R.id.tvNameUrser);
        tvPhoneUrser=itemView.findViewById(R.id.tvPhoneUrser);
        imgDel=itemView.findViewById(R.id.imgDel);
    }
}
