package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.bookmanager.R;
import com.example.bookmanager.adapter.ListCatogoryAdapter;
import com.example.bookmanager.dao.CatogoryDAO;
import com.example.bookmanager.model.Catogory;

import java.util.List;

public class ListCatogoryActivity extends AppCompatActivity {
    private Toolbar tbListCatogory;
    private RecyclerView rvListCatogry;
    private CatogoryDAO catogoryDAO;
    private List<Catogory> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_catogory);
        tbListCatogory = findViewById(R.id.tbListCatogory);
        rvListCatogry=findViewById(R.id.rvListCatogory);
        tbListCatogory.setTitle("Danh sách loại");
        setSupportActionBar(tbListCatogory);

        catogoryDAO=new CatogoryDAO(this);
        list=catogoryDAO.getAllCatogory();
        ListCatogoryAdapter listCatogoryAdapter=new ListCatogoryAdapter(this,list);
        LinearLayoutManager verticle = new LinearLayoutManager(this);
        rvListCatogry.setAdapter(listCatogoryAdapter);
        rvListCatogry.setLayoutManager(verticle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_catogory, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itListCatogory) {
            Intent intent = new Intent(this, AddCatogoryActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}
