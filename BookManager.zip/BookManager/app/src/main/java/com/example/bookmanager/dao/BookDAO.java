package com.example.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.bookmanager.model.Book;
import com.example.bookmanager.model.Catogory;
import com.example.bookmanager.sqlite.BookDatabaseHelper;

import java.util.ArrayList;
import java.util.List;


public class BookDAO {
    public static final String TABLE_NAME_BOOK = "Sach";
    private SQLiteDatabase db;
    private BookDatabaseHelper bookDatabaseHelper;
    public static final String CREATE_TABLE_BOOK = "CREATE TABLE Sach(maSach integer primary key," +
            "maTheLoaiBook text,tieuDe text, tacGia text,nxb text,giaBan text,soLuong text)";

    public BookDAO(Context context) {
        bookDatabaseHelper = new BookDatabaseHelper(context);
        db = bookDatabaseHelper.getWritableDatabase();
    }

    public boolean insertBook(Book book) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("maSach", book.getMaSach());
        contentValues.put("maTheLoaiBook", book.getMaTheLoaiBook());
        contentValues.put("tieuDe", book.getTieuDe());
        contentValues.put("tacGia", book.getTacGia());
        contentValues.put("nxb", book.getNxb());
        contentValues.put("giaBan", book.getGiaBan());
        contentValues.put("soLuong", book.getSoLuong());

        long result = db.insert(TABLE_NAME_BOOK, null, contentValues);
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    public int delBook(String maSach) {
        int result = db.delete(TABLE_NAME_BOOK, "maSach = ?", new String[]{maSach});
        return result;
    }

    public boolean UpdateBook(Book book) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("maSach", book.getMaSach());
        contentValues.put("tieuDe", book.getTieuDe());
        contentValues.put("tacGia", book.getTacGia());
        contentValues.put("nxb", book.getNxb());
        contentValues.put("giaBan", book.getGiaBan());
        contentValues.put("soLuong", book.getSoLuong());

        long result = db.update(TABLE_NAME_BOOK, contentValues, "maSach=?", new String[]{book.getMaSach()});
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            return false;
        }
        return true;
    }

    public List<Book> getAllBook() {
        List<Book> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME_BOOK, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Book book = new Book();
            book.setMaSach(cursor.getString(0));
            book.setMaTheLoaiBook(cursor.getString(1));
            book.setTieuDe(cursor.getString(2));
            book.setTacGia(cursor.getString(3));
            book.setNxb(cursor.getString(4));
            book.setGiaBan(cursor.getString(5));
            book.setSoLuong(cursor.getString(6));
            list.add(book);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public Book getSachByID(String maSach){
        Book s = null;
        //WHERE clause
        String selection = "maSach= ?";
        //WHERE clause arguments
        String[] selectionArgs = {maSach};
        Cursor c = db.query(TABLE_NAME_BOOK,null,selection,selectionArgs,null,null,null);
        c.moveToFirst();
        while (c.isAfterLast()==false){
            s = new Book();
            s.setMaSach(c.getString(0));
            s.setMaTheLoaiBook(c.getString(1));
            s.setTieuDe(c.getString(2));
            s.setTacGia(c.getString(3));
            s.setNxb(c.getString(4));
            s.setGiaBan(c.getString(5));
            s.setSoLuong(c.getString(6));
            break;
        }
        c.close();
        return s;
    }
}
