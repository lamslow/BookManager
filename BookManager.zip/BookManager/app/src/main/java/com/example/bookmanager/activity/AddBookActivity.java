package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.adapter.SpinnerBookAdapter;
import com.example.bookmanager.dao.BookDAO;
import com.example.bookmanager.dao.CatogoryDAO;
import com.example.bookmanager.model.Book;
import com.example.bookmanager.model.Catogory;

import java.util.List;

public class AddBookActivity extends AppCompatActivity {
    private SpinnerBookAdapter spinnerBookAdapter;
    private List<Catogory> list;
    private Toolbar tbAddBook;
    private Spinner spBook;
    private EditText edtTenSach,edtMaSach,edtTacGia,edtNXB,edtGiaBan,edtSoLuong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        tbAddBook = findViewById(R.id.tbAddBook);
        spBook=findViewById(R.id.spBook);
        tbAddBook.setTitle("Sách");
        setSupportActionBar(tbAddBook);
        unit();

        CatogoryDAO catogoryDAO=new CatogoryDAO(this);
        list=catogoryDAO.getAllCatogory();
        spinnerBookAdapter =new SpinnerBookAdapter(this,list);
        spBook.setAdapter(spinnerBookAdapter);

    }
    private void unit(){
        edtMaSach=findViewById(R.id.edtMaSach);
        edtNXB=findViewById(R.id.edtNXB);
        edtTacGia=findViewById(R.id.edtTacGia);
        edtTenSach=findViewById(R.id.edtNameBook);
        edtSoLuong=findViewById(R.id.edtSoLuongMua);
        edtGiaBan=findViewById(R.id.edtGiaBan);
    }

    public void openListBook(View view) {
        Intent intent = new Intent(this, ListBookActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_book, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itBook) {
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void addBook(View view) {
        Catogory catogory=new Catogory();
        Book book=new Book();
        book.giaBan=edtGiaBan.getText().toString();
        book.maSach=edtMaSach.getText().toString();
        book.nxb=edtNXB.getText().toString();
        book.soLuong=edtSoLuong.getText().toString();
        book.tieuDe=edtTenSach.getText().toString();
        book.tacGia=edtTacGia.getText().toString();
        book.maTheLoaiBook =spBook.getSelectedItem().toString();
        BookDAO bookDAO=new BookDAO(this);
        boolean result= bookDAO.insertBook(book);
        if(result){
            Toast.makeText(this, "Thêm thành công", Toast.LENGTH_SHORT).show();
            edtSoLuong.setText("");
            edtGiaBan.setText("");
            edtTenSach.setText("");
            edtTacGia.setText("");
            edtNXB.setText("");
            edtMaSach.setText("");
        }else {
            Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
        }
    }
}
