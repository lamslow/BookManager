package com.example.bookmanager.model;

public class Urser {
    String userName;
    String password;
    String phone;
    String fullname;

    public Urser() {
        this.userName ="no name";
        this.password="123";
        this.fullname="no name";
        this.phone="123";

    }
    public Urser(String urserName, String password){
        this.userName=urserName;
        this.password=password;
    }

    public Urser(String urserName, String password, String phone, String fullname) {
        this.userName = urserName;
        this.password = password;
        this.phone = phone;
        this.fullname = fullname;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
}
