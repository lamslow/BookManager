package com.example.bookmanager.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.bookmanager.R;

public class HomePageActivity extends AppCompatActivity {
    private Toolbar tbHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        tbHome = findViewById(R.id.tbHome);
        tbHome.setTitle("Book Manager");
        setSupportActionBar(tbHome);
    }

    public void openNguoiDung(View view) {
        Intent intent = new Intent(this, AddUrserActivity.class);
        startActivity(intent);
    }

    public void openAddCatogory(View view) {
        Intent intent = new Intent(this, AddCatogoryActivity.class);
        startActivity(intent);
    }

    public void openAddBook(View view) {
        Intent intent = new Intent(this, AddBookActivity.class);
        startActivity(intent);
    }

    public void openAddHoaDon(View view) {
        Intent intent = new Intent(this, AddHoaDonActivity.class);
        startActivity(intent);
    }
}
