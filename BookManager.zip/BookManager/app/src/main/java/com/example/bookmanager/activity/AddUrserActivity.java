package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.model.Urser;

public class
AddUrserActivity extends AppCompatActivity {
    private Toolbar tbAddUrser;
    private EditText edtUserName, edtPass, edtPhone, edtFullName;
    private NguoDungDAO nguoDungDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_urser);
        tbAddUrser = findViewById(R.id.tbAddUrser);
        tbAddUrser.setTitle("Người dùng");
        setSupportActionBar(tbAddUrser);
        init();
    }

    private void init() {
        edtUserName = findViewById(R.id.edtNameUrser);
        edtPass = findViewById(R.id.edtPassUrser);
        edtFullName = findViewById(R.id.edtFullName);
        edtPhone = findViewById(R.id.edtNumberUrser);


    }

    public void openListUrser(View view) {
        Intent intent = new Intent(this, ListUrserActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_book, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itBook) {
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void addNewUrser(View view) {

        nguoDungDAO = new NguoDungDAO(this);
        String name = edtUserName.getText().toString();
        String pass = edtPass.getText().toString();
        String fullname = edtFullName.getText().toString();
        String phone = edtPhone.getText().toString();
        Urser urser = new Urser(name, pass, phone, fullname);
        boolean isInsert = nguoDungDAO.insertNguoiDung(urser);
        if (isInsert) {
            Toast.makeText(this, "Them thanh cong", Toast.LENGTH_SHORT).show();
            edtFullName.setText("");
            edtPass.setText("");
            edtPhone.setText("");
            edtUserName.setText("");
        } else {
            Toast.makeText(this, "Them khong thanh cong", Toast.LENGTH_SHORT).show();
        }
    }
}
