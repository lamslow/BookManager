package com.example.bookmanager.hoder;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;

public class HDCTHoder extends RecyclerView.ViewHolder {
    public TextView tvmaMaSachGH,tvGiaSachGH,tvSoLuongGH,tvThanhTien;
    public ImageView imgDelHDCT;
    public HDCTHoder(@NonNull View itemView) {
        super(itemView);
        tvGiaSachGH=itemView.findViewById(R.id.tvGiaSachGH);
        tvmaMaSachGH=itemView.findViewById(R.id.tvMaSachGH);
        tvSoLuongGH=itemView.findViewById(R.id.tvSoLuongGH);
        tvThanhTien=itemView.findViewById(R.id.tvThanhTien);
        imgDelHDCT=itemView.findViewById(R.id.imgDelHDCT);

    }
}
