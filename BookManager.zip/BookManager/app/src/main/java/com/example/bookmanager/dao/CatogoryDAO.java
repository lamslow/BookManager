package com.example.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.bookmanager.model.Book;
import com.example.bookmanager.model.Catogory;
import com.example.bookmanager.model.Urser;
import com.example.bookmanager.sqlite.BookDatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class CatogoryDAO {
    public static final String TABLE_NAME_CATOGORY = "TheLoaiSach";
    private SQLiteDatabase db;
    private BookDatabaseHelper databaseHelper;
    public static final String CREATE_TABLE_CATOGORY = "CREATE TABLE TheLoaiSach" +
            " (maTheLoai integer primary key,tenTheLoai text,moTa text, viTri text)";

    public CatogoryDAO(Context context) {
        databaseHelper = new BookDatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();
    }

    public boolean insertCatogory(Catogory catogory) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("maTheLoai",catogory.getMaTheLoai());
        contentValues.put("tenTheLoai", catogory.getTenTheLoai());
        contentValues.put("moTa", catogory.getMoTa());
        contentValues.put("viTri", catogory.getViTri());


        long result = db.insert(TABLE_NAME_CATOGORY, null, contentValues);
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            Log.e("abc", e.toString());
            return false;
        }
        return true;
    }


    public int delLoaiSach(String maTheLoai) {
        int result = db.delete(TABLE_NAME_CATOGORY, "maTheLoai=?", new String[]{maTheLoai});
        return result;
    }

    public List<Catogory> getAllCatogory() {
        List<Catogory> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME_CATOGORY, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Catogory catogory = new Catogory();
            catogory.setMaTheLoai(cursor.getString(0));
            catogory.setTenTheLoai(cursor.getString(1));
            catogory.setMoTa(cursor.getString(2));
            catogory.setViTri(cursor.getString(3));
            list.add(catogory);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<Catogory> getAllCatogoryName() {
        List<Catogory> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME_CATOGORY, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Catogory catogory = new Catogory();
            catogory.setMaTheLoai(cursor.getString(0));
            catogory.setTenTheLoai(cursor.getString(1));
            list.add(catogory);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public int UpdateCatogory(Catogory catogory){
        ContentValues contentValues=new ContentValues();
        contentValues.put("maTheLoaiBook",catogory.getMaTheLoai());
        contentValues.put("tenTheLoai",catogory.getTenTheLoai());
        contentValues.put("moTa",catogory.getMoTa());
        contentValues.put("viTri",catogory.getViTri());
        int result= db.update(TABLE_NAME_CATOGORY,contentValues,"maTheLoaiBook=?",new String[]{catogory.getMaTheLoai()});
        return result;
    }

}
