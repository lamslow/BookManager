package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.adapter.ListUrserAdapter;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.model.Urser;

import java.util.List;

public class ListUrserActivity extends AppCompatActivity {
    private Toolbar tbListUser;
    private NguoDungDAO nguoDungDAO;
    private RecyclerView rvUser;
    private List<Urser> list;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_urser);
        rvUser=findViewById(R.id.rvUrser);
        tbListUser = findViewById(R.id.tbListUrser);
        tbListUser.setTitle("Danh sách người dùng");

        setSupportActionBar(tbListUser);

        nguoDungDAO=new NguoDungDAO(this);
        list=nguoDungDAO.getAllUrser();
        ListUrserAdapter listUrserAdapter=new ListUrserAdapter(this,list);
        LinearLayoutManager verticle = new LinearLayoutManager(this);
        rvUser.setAdapter(listUrserAdapter);
        rvUser.setLayoutManager(verticle);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_urser, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itListUrser) {
            Intent intent = new Intent(this, AddUrserActivity.class);
            startActivity(intent);
        }

        if (item.getItemId()== R.id.itChangePass){
            Intent intent=new Intent(this,ChangePassActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}
