package com.example.bookmanager.model;

public class Book {

    public String maSach;
    public String maTheLoaiBook;



    public String tieuDe;
    public String tacGia;
    public String nxb;
    public String soLuong;
    public String giaBan;

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }


    public String getMaTheLoaiBook() {
        return maTheLoaiBook;
    }

    public void setMaTheLoaiBook(String maTheLoaiBook) {
        this.maTheLoaiBook = maTheLoaiBook;
    }

    public String getTieuDe() {
        return tieuDe;
    }

    public void setTieuDe(String tieuDe) {
        this.tieuDe = tieuDe;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public String getNxb() {
        return nxb;
    }

    public void setNxb(String nxb) {
        this.nxb = nxb;
    }

    public String getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(String soLuong) {
        this.soLuong = soLuong;
    }

    public String getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(String giaBan) {
        this.giaBan = giaBan;
    }
}
