package com.example.bookmanager.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.CatogoryDAO;
import com.example.bookmanager.hoder.ListCatogoryHoder;
import com.example.bookmanager.model.Catogory;

import java.util.List;

public class ListCatogoryAdapter extends RecyclerView.Adapter<ListCatogoryHoder> {
    private Context context;
    private List<Catogory> list;
    private CatogoryDAO catogoryDAO;
    private ListCatogoryAdapter listCatogoryAdapter;
    public ListCatogoryAdapter(Context context, List<Catogory> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ListCatogoryHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.catogorys, parent, false);
        ListCatogoryHoder listCatogoryHoder = new ListCatogoryHoder(view);
        return listCatogoryHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListCatogoryHoder holder, final int position) {
        holder.tvTenLoai.setText(list.get(position).getTenTheLoai());
        holder.tvMaLoai.setText(position + 1 + "");
        holder.imgDelCatogory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                catogoryDAO = new CatogoryDAO(context);
                String maLoai = String.valueOf(list.get(position).getMaTheLoai());
                int result = catogoryDAO.delLoaiSach(maLoai);
                if (result > 0) {
                    Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                    list.remove(position);
                    notifyDataSetChanged();
                } else {
                    Toast.makeText(context, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                }
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View dialogCatogory = LayoutInflater.from(context).inflate(R.layout.dialog_catogory, null);
                builder.setView(dialogCatogory);
                builder.setTitle("Chi tiết thể loại sách");
                final AlertDialog dialog = builder.show();

                final EditText edtMaLoai = dialogCatogory.findViewById(R.id.edtMaTheLoai);
                final EditText edtTenTheLoai = dialogCatogory.findViewById(R.id.edtTenTheLoaiCa);
                final EditText edtViTri = dialogCatogory.findViewById(R.id.edtViTriLoai);
                final EditText edtMoTaLoai = dialogCatogory.findViewById(R.id.edtMoTaLoaiCa);
                Button btnUpdateCatogory=dialogCatogory.findViewById(R.id.btnupdateCatogory);

                edtMaLoai.setText(list.get(position).getMaTheLoai());
                edtTenTheLoai.setText(list.get(position).getTenTheLoai());
                edtMoTaLoai.setText(list.get(position).getMoTa());
                edtViTri.setText(list.get(position).getViTri());
                btnUpdateCatogory.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Catogory catogory=new Catogory();
                        catogory.setMaTheLoai(edtMaLoai.getText().toString());
                        catogory.setViTri(edtViTri.getText().toString());
                        catogory.setMoTa(edtMoTaLoai.getText().toString());
                        catogory.setTenTheLoai(edtTenTheLoai.getText().toString());

                        CatogoryDAO catogoryDAO=new CatogoryDAO(context);
                        int result = catogoryDAO.UpdateCatogory(catogory);
                        if (result>0){
                            Toast.makeText(context, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            list=catogoryDAO.getAllCatogory();
                            listCatogoryAdapter=new ListCatogoryAdapter(context,list);
                            notifyDataSetChanged();
                        }else {
                            Toast.makeText(context, "Cập nhật không thành công", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }

                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
