package com.example.bookmanager.hoder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;

public class ListBookHoder extends RecyclerView.ViewHolder {
    public TextView tvNameBook,tvGiaSach;
    public ImageView imgDelBook;
    public ListBookHoder(@NonNull View itemView) {
        super(itemView);
        imgDelBook=itemView.findViewById(R.id.imgDelBook);
        tvNameBook = itemView.findViewById(R.id.tvNameBook);
        tvGiaSach = itemView.findViewById(R.id.tvGiaSach);
    }
}
