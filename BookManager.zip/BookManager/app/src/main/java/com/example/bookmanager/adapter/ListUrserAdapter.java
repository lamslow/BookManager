package com.example.bookmanager.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.hoder.ListUrserHoder;
import com.example.bookmanager.model.Urser;

import java.util.List;

public class ListUrserAdapter extends RecyclerView.Adapter<ListUrserHoder> {

    private List<Urser> list;
    private Context context;
    private ListUrserAdapter listUrserAdapter;

    public ListUrserAdapter(Context context, List<Urser> list) {
        this.list = list;
        this.context = context;

    }

    @NonNull
    @Override
    public ListUrserHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.urser, parent, false);
        ListUrserHoder listUrserHoder = new ListUrserHoder(view);
        return listUrserHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListUrserHoder holder, final int position) {
        holder.tvNameUrser.setText(list.get(position).getUserName());
        holder.tvPhoneUrser.setText(list.get(position).getPhone());
        holder.imgDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NguoDungDAO nguoDungDAO = new NguoDungDAO(context);
                int result = nguoDungDAO.delNguoiDung(list.get(position).getUserName());
                if (result > 0) {
                    Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                    list.remove(position);
                    notifyDataSetChanged();

                } else {
                    Toast.makeText(context, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                }

            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View dialogUser = LayoutInflater.from(context).inflate(R.layout.dialog_user, null);
                builder.setView(dialogUser);
                builder.setTitle("Người dùng chi tiết");
                final EditText tvName = dialogUser.findViewById(R.id.edtTenNguoiDung);
                final EditText tvphone = dialogUser.findViewById(R.id.edtSDT);
                final EditText tvTen = dialogUser.findViewById(R.id.edtTenDayDu);
                tvName.setText(list.get(position).getUserName());
                tvphone.setText(list.get(position).getPhone());
                tvTen.setText(list.get(position).getFullname());
                final AlertDialog alertDialog = builder.show();

                Button btnUpdateUser = dialogUser.findViewById(R.id.btnUpdateUser);
                btnUpdateUser.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Urser urser = new Urser();
                        urser.setUserName(tvName.getText().toString());
                        urser.setPhone(tvphone.getText().toString());
                        urser.setFullname(tvTen.getText().toString());
                        NguoDungDAO nguoDungDAO = new NguoDungDAO(context);
                        int result = nguoDungDAO.UpdateUser(urser);
                        if (result > 0) {
                            Toast.makeText(context, "Update thành công", Toast.LENGTH_SHORT).show();
                            list = nguoDungDAO.getAllUrser();
                            listUrserAdapter = new ListUrserAdapter(context, list);
                            notifyDataSetChanged();
                            alertDialog.dismiss();

                        } else {
                            Toast.makeText(context, "Update khong thanh cong", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }

                    }
                });

            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
