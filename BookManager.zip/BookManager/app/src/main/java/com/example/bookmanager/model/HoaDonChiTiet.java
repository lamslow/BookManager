package com.example.bookmanager.model;

public class HoaDonChiTiet {
    public String maHDCT;
    public HoaDon maHoaDon;
    public String soLuongMua;
    public Book maSach;

    public String getMaHDCT() {
        return maHDCT;
    }

    public void setMaHDCT(String maHDCT) {
        this.maHDCT = maHDCT;
    }

    public HoaDon getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(HoaDon maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getSoLuongMua() {
        return soLuongMua;
    }

    public void setSoLuongMua(String soLuongMua) {
        this.soLuongMua = soLuongMua;
    }

    public Book getMaSach() {
        return maSach;
    }

    public void setMaSach(Book maSach) {
        this.maSach = maSach;
    }

    public HoaDonChiTiet(HoaDon maHoaDon, String soLuongMua, Book maSach) {
        this.maHoaDon = maHoaDon;
        this.soLuongMua = soLuongMua;
        this.maSach = maSach;
    }

    public HoaDonChiTiet() {
    }


}
