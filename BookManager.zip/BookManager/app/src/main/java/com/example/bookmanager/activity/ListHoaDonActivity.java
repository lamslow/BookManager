package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.bookmanager.R;

public class ListHoaDonActivity extends AppCompatActivity {
    private Toolbar tbListHoaDon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_hoa_don);
        tbListHoaDon = findViewById(R.id.tbListHoaDon);
        tbListHoaDon.setTitle("Danh sách hóa đơn");
        setSupportActionBar(tbListHoaDon);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_hd, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itListHoaDon) {
            Intent intent = new Intent(this, AddHoaDonActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}
