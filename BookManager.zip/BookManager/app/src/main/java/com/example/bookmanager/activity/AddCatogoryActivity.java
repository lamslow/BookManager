package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.CatogoryDAO;
import com.example.bookmanager.model.Catogory;

public class AddCatogoryActivity extends AppCompatActivity {
    private Toolbar tbAddCatogory;
    private EditText edtMaLoai, edtViTri, edtMoTa, edtTenLoai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_catogory);
        tbAddCatogory = findViewById(R.id.tbAddCatogory);
        tbAddCatogory.setTitle("Loại sách");
        setSupportActionBar(tbAddCatogory);
        Unit();
    }

    private void Unit() {
        edtMaLoai = findViewById(R.id.edtMaLoai);
        edtMoTa = findViewById(R.id.edtMoTa);
        edtTenLoai = findViewById(R.id.edtTenLoai);
        edtViTri = findViewById(R.id.edtViTri);
    }

    public void openListCatogory(View view) {
        Intent intent = new Intent(this, ListCatogoryActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_book, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itBook) {
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    public void addCatogory(View view) {
        CatogoryDAO catogoryDAO = new CatogoryDAO(this);
        Catogory catogory = new Catogory();
        catogory.maTheLoai = edtMaLoai.getText().toString();
        catogory.moTa = edtMoTa.getText().toString();
        catogory.tenTheLoai = edtTenLoai.getText().toString();
        catogory.viTri = edtViTri.getText().toString();
        boolean isInsert = catogoryDAO.insertCatogory(catogory);
        if (isInsert) {
            Toast.makeText(this, "Thêm loại sách thành công", Toast.LENGTH_SHORT).show();
            edtMaLoai.setText("");
            edtViTri.setText("");
            edtMoTa.requestFocus();
            edtTenLoai.setText("");
            edtMoTa.setText("");
            edtMaLoai.requestFocus();
        } else {
            Toast.makeText(this, "Thêm loại sách thất bại", Toast.LENGTH_SHORT).show();
        }
    }
}
