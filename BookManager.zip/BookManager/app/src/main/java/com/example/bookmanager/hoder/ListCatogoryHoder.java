package com.example.bookmanager.hoder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;

public class ListCatogoryHoder extends RecyclerView.ViewHolder {
    public TextView tvMaLoai,tvTenLoai;
    public ImageView imgDelCatogory;
    public ListCatogoryHoder(@NonNull View itemView) {
        super(itemView);
        tvMaLoai=itemView.findViewById(R.id.tvMaLoai);
        tvTenLoai=itemView.findViewById(R.id.tvTenLoai);
        imgDelCatogory=itemView.findViewById(R.id.imgDelCatogory);
    }
}
