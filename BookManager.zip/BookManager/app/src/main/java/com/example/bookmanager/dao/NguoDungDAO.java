package com.example.bookmanager.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.bookmanager.model.Urser;
import com.example.bookmanager.sqlite.BookDatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class NguoDungDAO {
    public static final String TABLE_NAME = "NguoiDung";
    private SQLiteDatabase db;
    private BookDatabaseHelper databaseHelper;
    public static final String CREATE_TABLE =
            "CREATE TABLE NguoiDung(userName text " +
                    "primary key,password text,phone text,fullname text)";

    public NguoDungDAO(Context context) {
        databaseHelper = new BookDatabaseHelper(context);
        db = databaseHelper.getWritableDatabase();
    }

    public boolean insertNguoiDung(Urser urser) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userName", urser.getUserName());
        contentValues.put("password", urser.getPassword());
        contentValues.put("phone", urser.getPhone());
        contentValues.put("fullname", urser.getFullname());
        long result = db.insert(TABLE_NAME, null, contentValues);
        try {
            if (result == -1) {
                return false;
            }
        } catch (Exception e) {

            Log.e("abc", e.toString());
            return false;
        }
        return true;
    }

    public int UpdateUser(Urser urser){
        ContentValues contentValues=new ContentValues();
        contentValues.put("username",urser.getUserName());
        contentValues.put("fullname",urser.getFullname());
        contentValues.put("phone",urser.getPhone());
        int result= db.update(TABLE_NAME,contentValues,"username=?",new String[]{urser.getUserName()});
        return result;
    }

    public int delNguoiDung(String ursername) {
        int result = db.delete(TABLE_NAME, "username=?", new String[]{ursername});
        return result;
    }

    public List<Urser> getAllUrser() {
        List<Urser> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_NAME, null,
                null, null, null, null, null);
        cursor.moveToFirst();
        while (cursor.isAfterLast() == false) {
            Urser urser = new Urser();
            urser.setUserName(cursor.getString(0));
            urser.setPassword(cursor.getString(1));
            urser.setPhone(cursor.getString(2));
            urser.setFullname(cursor.getString(3));
            list.add(urser);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public boolean isLogin(Urser urser) {
        String sqlSelect = "select username, password from nguoidung " +
                "where username=? and password=?";
        String username = urser.getUserName();
        String password = urser.getPassword();
        //Thực hiện lệnh truy vấn
        Cursor c = db.rawQuery(sqlSelect, new String[]{username, password});
        //nếu con trỏ, trỏ tới bản ghi đầu tiên, tức là có dữ liệu username và password trong CSDL
        if (c.moveToFirst()) {
            return true;
        }
        return false;
    }

    public boolean isChangePassword(Urser urser) {
        ContentValues values = new ContentValues();
        values.put("username", urser.getUserName());
        values.put("password", urser.getPassword());

        int result = db.update(TABLE_NAME, values, "username=?",
                new String[]{urser.getUserName()});

        if (result == -1) {
            return false;
        }

        return true;
    }
}


