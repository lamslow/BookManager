package com.example.bookmanager.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.activity.HomePageActivity;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.model.Urser;

public class LoginActivity extends AppCompatActivity {
    private Toolbar tbLogin;
    private EditText edtNameLogin, edtPassLogin;
    CheckBox chkRemeber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        chkRemeber=findViewById(R.id.chkRemember);
        edtNameLogin=findViewById(R.id.edtNameLogin);
        edtPassLogin=findViewById(R.id.edtPasswordLogin);
        tbLogin = findViewById(R.id.tbLogin);
        tbLogin.setTitle("Đăng nhập");
        setSupportActionBar(tbLogin);
    }

    public void openHomePage(View view) {
        NguoDungDAO nguoDungDAO=new NguoDungDAO(this);
        String userName=edtNameLogin.getText().toString();;
        String password=edtPassLogin.getText().toString();
        Urser urser=new Urser(userName,password);
        boolean result = nguoDungDAO.isLogin(urser);
        if(result){
            Toast.makeText(this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
            rememberPass(userName,password,chkRemeber.isChecked());
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }else {
            Toast.makeText(this, "Đăng nhập không thành công", Toast.LENGTH_SHORT).show();
        }


    }

    public void rememberPass(String u,String p,boolean status) {
        SharedPreferences preferences= getSharedPreferences("USER_FILE",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        if(!status){
            editor.clear();
        }else {
            editor.putString("USERNAME",u);
            editor.putString("PASSWORD",p);
            editor.putBoolean("REMEMBER",status);
        }
        editor.commit();
    }
}
