package com.example.bookmanager.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.bookmanager.dao.BookDAO;
import com.example.bookmanager.dao.CatogoryDAO;
import com.example.bookmanager.dao.HDCTDao;
import com.example.bookmanager.dao.HoaDonDAO;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.model.HoaDon;

public class BookDatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="dbBookManager";
    public static final int VERSON=1;
    public BookDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSON);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(NguoDungDAO.CREATE_TABLE);
        db.execSQL(BookDAO.CREATE_TABLE_BOOK);
        db.execSQL(CatogoryDAO.CREATE_TABLE_CATOGORY);
        db.execSQL(HoaDonDAO.CREATE_TABLE_HD);
        db.execSQL(HDCTDao.CREATE_TABLE_HDCT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+NguoDungDAO.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+BookDAO.TABLE_NAME_BOOK);
        db.execSQL("DROP TABLE IF EXISTS "+CatogoryDAO.TABLE_NAME_CATOGORY);
        db.execSQL("DROP TABLE IF EXISTS "+ HoaDonDAO.TABLE_NAME_HD);
    }
}
