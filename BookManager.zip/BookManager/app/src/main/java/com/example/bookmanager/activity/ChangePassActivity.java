package com.example.bookmanager.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.dao.NguoDungDAO;
import com.example.bookmanager.model.Urser;

public class ChangePassActivity extends AppCompatActivity {
    EditText edtChangePass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pass);
        edtChangePass=findViewById(R.id.edtChangePass);
    }

    public void ChangePass(View view) {
        NguoDungDAO nguoDungDAO=new NguoDungDAO(this);
        SharedPreferences preferences=getSharedPreferences("USER_FILE",MODE_PRIVATE);
        String urserName = preferences.getString("USERNAME","");
        String password=edtChangePass.getText().toString();
        Urser urser=new Urser(urserName,password);
        if (nguoDungDAO.isChangePassword(urser)){
            Toast.makeText(this, "Đổi mật khẩu thành công", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Đổi mật khẩu thất bại", Toast.LENGTH_SHORT).show();
        }
    }
}
