package com.example.bookmanager.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bookmanager.R;
import com.example.bookmanager.adapter.GioHangAdapter;
import com.example.bookmanager.dao.BookDAO;
import com.example.bookmanager.dao.HDCTDao;
import com.example.bookmanager.dao.HoaDonDAO;
import com.example.bookmanager.model.Book;
import com.example.bookmanager.model.HoaDon;
import com.example.bookmanager.model.HoaDonChiTiet;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class AddHoaDonActivity extends AppCompatActivity {
    private Toolbar tbHoaDon;
    private EditText edtMaSach, edtSoLuongMua, edtNgayMua, edtMaHoaDon;
    Button btnThem;
    RecyclerView rvListGioHang;
    HDCTDao hdctDao;
    BookDAO bookDAO;
    List<HoaDonChiTiet> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoa_don);
        edtMaSach = findViewById(R.id.edtMaSachCT);
        edtNgayMua = findViewById(R.id.edtNgayMua);
        edtMaHoaDon = findViewById(R.id.edtMaHoaDon);
        rvListGioHang = findViewById(R.id.rvListGioHang);
        btnThem = findViewById(R.id.btnThem);
        edtSoLuongMua = findViewById(R.id.edtSoLuongMua);
        tbHoaDon = findViewById(R.id.tbHoaDon);
        tbHoaDon.setTitle("Hóa Đơn");
        setSupportActionBar(tbHoaDon);
        list=new ArrayList<>();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date();
        edtNgayMua.setText(simpleDateFormat.format(date));
    }

    public void openListHoaDon(View view) {
        Intent intent = new Intent(this, ListHoaDonActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_book, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.itBook) {
            Intent intent = new Intent(this, HomePageActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    public void addGH(View view) {
        hdctDao = new HDCTDao(this);
        bookDAO = new BookDAO(this);
        Book book = bookDAO.getSachByID(edtMaSach.getText().toString());

            HoaDon hoaDon = new HoaDon();
            hoaDon.setMaHoaDon(edtMaHoaDon.getText().toString());
            hoaDon.setNgayMua(edtNgayMua.getText().toString());
            HoaDonChiTiet hoaDonChiTiet = new HoaDonChiTiet(hoaDon,
                    edtSoLuongMua.getText().toString(), book);
            list.add(hoaDonChiTiet);
            GioHangAdapter gioHangAdapter = new GioHangAdapter(this, list);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            rvListGioHang.setAdapter(gioHangAdapter);
            rvListGioHang.setLayoutManager(linearLayoutManager);

    }

    public int checkMaSach(List<HoaDonChiTiet> chiTietList, String maSach) {
        int pos = -1;
        for (int i = 0; i < chiTietList.size(); i++) {
            HoaDonChiTiet hdct = chiTietList.get(i);
            if (hdct.getMaSach().getMaSach().equalsIgnoreCase(maSach)) {
                pos = i;
                break;
            }
        }
        return pos;
    }

    public void saveHoaDon(View view) {
        HoaDonDAO hoaDonDAO = new HoaDonDAO(this);
        HoaDon hoaDon = new HoaDon();
        hoaDon.setMaHoaDon(edtMaHoaDon.getText().toString());
        hoaDon.setNgayMua(edtNgayMua.getText().toString());
        for (int i = 0; i < list.size(); i++) {
            HoaDonChiTiet hoaDonChiTiet=new HoaDonChiTiet(hoaDon,list.get(i).soLuongMua,list.get(i).maSach);
            HDCTDao hdctDao=new HDCTDao(this);
            hdctDao.inserHoaDonChiTiet(hoaDonChiTiet);
        }

        boolean result = hoaDonDAO.insertHoaDon(hoaDon);
        if (result) {
            Toast.makeText(this, "Thêm thành công", Toast.LENGTH_SHORT).show();
            edtSoLuongMua.setText("");
            edtMaHoaDon.setText("");
            edtMaSach.setText("");
            list.clear();
            GioHangAdapter gioHangAdapter = new GioHangAdapter(this, list);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            rvListGioHang.setAdapter(gioHangAdapter);
            rvListGioHang.setLayoutManager(linearLayoutManager);
        } else {
            Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
        }

    }
}

