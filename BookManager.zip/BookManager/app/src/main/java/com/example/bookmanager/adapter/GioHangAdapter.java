package com.example.bookmanager.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bookmanager.R;
import com.example.bookmanager.hoder.HDCTHoder;
import com.example.bookmanager.model.HoaDonChiTiet;

import java.util.List;

public class GioHangAdapter extends RecyclerView.Adapter<HDCTHoder> {
    Context context;
    List<HoaDonChiTiet> hoaDonChiTietList;

    public GioHangAdapter(Context context, List<HoaDonChiTiet> hoaDonChiTietList) {
        this.context = context;
        this.hoaDonChiTietList = hoaDonChiTietList;
    }

    @NonNull
    @Override
    public HDCTHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.giohang,parent,false);
        HDCTHoder hdctHoder=new HDCTHoder(view);
        return hdctHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull HDCTHoder holder, final int position) {
        holder.tvmaMaSachGH.setText(hoaDonChiTietList.get(position).getMaSach().getMaSach());
        holder.tvGiaSachGH.setText(hoaDonChiTietList.get(position).getMaSach().getGiaBan()+" VND");
        holder.tvSoLuongGH.setText(hoaDonChiTietList.get(position).getSoLuongMua());
        holder.tvThanhTien.setText(Double.parseDouble(hoaDonChiTietList.get(position).getSoLuongMua())*
                Double.parseDouble(hoaDonChiTietList.get(position).getMaSach().getGiaBan())+" VND");
        holder.imgDelHDCT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hoaDonChiTietList.remove(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return hoaDonChiTietList.size();
    }
}
